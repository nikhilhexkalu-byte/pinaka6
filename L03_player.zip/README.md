# L03 — Indrajit: The Invisible War

*Meghnad — Indrajit, "conqueror of Indra" — never fought where he could be seen. From the
clouds over Lanka he moved his legions by a command network of his own devising, and laid over
every true order a storm of illusions: false commands that carry every mark of authenticity,
orders replayed out of their hour, the same word spoken twice from two towers whose water-clocks
no longer agree. Two of Rama's scouts, posted on the heights of Trikuta and Suvela, each wrote
down everything that crossed the air above them. Neither saw the whole war. Between their two
records lies one genuine chain of command — and a great deal that was meant to deceive.*

*Ravana's war-council will not move on a rumour. Bring them the true transmission, and the one
post it came from, and prove you saw through the illusion — then the seal will open.*

## What you are given

Two packet captures from the two scout-monitors above Lanka (custom transport, **no protocol
specification is published — you must reverse it from the bytes**):

| File | What it is |
|---|---|
| `capture_trikuta.pcap` | The northern monitor (Trikuta heights). It keeps its own clock — treat it as the reference. |
| `capture_suvela.pcap`  | The southern monitor (Suvela hill). Its clock runs at a different rate and offset from Trikuta's. |

The two monitors watched **different stretches of the network**, so neither capture alone is the
whole story. A few frames — the war-council's periodic watch-fire beacons — were seen by **both**
monitors; those are your only bridge between the two clocks. Everything in these files is a real,
internally consistent recording. The flag is **not** present in any file.

## Your goal

Recover the **genuine command transmission** Indrajit actually sent — the ordered sequence of
orders that truly crossed the network — after:

- separating the genuine orders from the **illusions** (commands that look perfectly authentic
  but were forged by exploiting a weakness in how the transport authenticates its messages);
- reconciling **retransmissions and replays** (the same order can appear more than once);
- correlating the **two monitor clocks** onto one timeline so the orders fall into their true order.

Then identify the **post that originated** the genuine stream, and the one quantitative fact your
break of the authentication reveals: the **length, in bytes, of the secret key** the transport
uses. Present all three to the war-council's seal (the validator) for your instance. It checks
your answer server-side and returns the flag only on an exact match. Guessing will not find it.

## Submission

`POST /war/command` with a JSON body:

```json
{
  "command_transcript": "NAGAPASHA-TRANSCRIPT v1\n#1 <ORDER>\n#2 <ORDER>\n...",
  "origin_node": <integer>,
  "key_length": <integer>
}
```

- **command_transcript** — the genuine orders, in true chronological order, one per line as
  `#<position> <ACTION> sector=<name> tick=<number>`, under a first line `NAGAPASHA-TRANSCRIPT v1`.
  Grading is case- and whitespace-insensitive; the **order, actions, sectors and ticks** must all
  be exactly right together. (The `<ACTION>` and `<name>` tokens are the human-readable names the
  orders decode to — recover them from the command payloads.)
- **origin_node** — the integer id of the network post that originated the genuine stream.
- **key_length** — the secret-key length (in bytes) your authentication break reveals.

A transmission that still trusts a forged order, that double-counts a replay, or that was never
placed on one common timeline will be refused.
