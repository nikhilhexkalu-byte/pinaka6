# L04 — Dronagiri: The Last Sanjeevani

*The war is lost unless the fallen rise, and only the Sanjeevani — the luminous herb of
Dronagiri — can raise them. Hanuman flew for it, but on the mountainside a thousand herbs
glowed alike in the dark, and he could not tell the one true Sanjeevani from its false kin.
So he tore the whole mountain loose and carried it to Lanka. Now the mountain's own research
survives only as a corrupted field archive: three replicated field nodes, their write-ahead
logs torn and overwritten, the spectrometer's calibration scattered, the terrain survey
intact. Among every record the mountain ever held, exactly one specimen is the real
Sanjeevani. Read it back out of the wreckage before the night ends.*

## What you are given

All files are custom, undocumented binary formats — no schema is published.

| File | What it is |
|---|---|
| `node0.seg`, `node1.seg`, `node2.seg` | Clean snapshot **segments** — the committed state of the specimen archive **as of the last checkpoint**, one per replicated field node. |
| `node0.wal`, `node1.wal`, `node2.wal` | The **write-ahead logs** appended after the checkpoint, one per node. They are damaged: some frames are torn, a tail span was overwritten, and — because replication was unreliable — some writes reached only a single node. |
| `instrument.cal` | The spectrometer calibration: the emission lines of the reference **calibration lamp**, from which the wavelength axis is recovered. |
| `dronagiri.dem` | The **terrain** digital elevation model of the mountain (an elevation grid). |

Every byte is part of one internally consistent survey — there is no random filler. The flag is
**not** present in any file.

## What is true of the mountain (the botanical facts)

- Each specimen record carries a 32-band **spectrum** (the instrument encodes it reversibly).
- The archive is a **replicated** versioned key-value store: each specimen (a numeric id) has
  versions stamped with a monotone sequence number. A write is only **committed** when it
  reached a **majority of the three nodes**; a write that reached only one node is not part of
  the true history. The snapshot segments are **stale** — committed writes made after the
  checkpoint survive only in the logs.
- The true Sanjeevani **glows**: after the wavelength axis is calibrated, its spectral peak
  lies in the luminescence window **1108–1123 nm**. Many false herbs glow too.
- The true Sanjeevani grows only on a **sunlit summit**: a terrain cell whose elevation is
  within the habitat band **3000–3400** (DEM units) **and** which is a strict local maximum —
  strictly higher than all eight of its neighbouring cells. Exactly one glowing committed
  specimen sits on such a cell.

## Your goal

Reconstruct the **single authentic specimen record** — the true Sanjeevani — that the mountain's
own corrupted survey, read correctly, uniquely determines, and present it to the seal (the
validator) for your instance. The seal checks your record against the mountain's true history
server-side and, only on an exact match, returns the flag. There is exactly one record that
passes; guessing will not find it.

## Submission

`POST /dronagiri/sanjeevani` with a JSON body:

```json
{
  "specimen_id": <int>,
  "commit_seqno": <int>,
  "cell": [x, y],
  "elevation": <int>,
  "peak_band": <int>,
  "peak_wavelength": [numerator, denominator],
  "wavelength_solution": [p_num, p_den, q_num, q_den],
  "restored_spectrum": [<int>, ... 32 bands],
  "committed_record_count": <int>,
  "committed_archive_digest": "<sha256 hex>"
}
```

- **specimen_id** — the id (key) of the authentic specimen.
- **commit_seqno** — the sequence number of its committed version.
- **cell** — the `[x, y]` terrain cell where it was collected.
- **elevation** — the DEM elevation at that cell.
- **peak_band** — the index (0–31) of its spectrum's dominant band.
- **peak_wavelength** — that band's true wavelength in nm, as a reduced fraction `[num, den]`.
- **wavelength_solution** — the recovered wavelength axis `nm = p·index + q`, as reduced
  fractions `[p_num, p_den, q_num, q_den]`.
- **restored_spectrum** — the 32 decoded band intensities of the authentic specimen, in order.
- **committed_record_count** — how many specimen records are in the committed archive you
  reconciled.
- **committed_archive_digest** — a fingerprint of that committed archive: for every committed
  specimen, the string `key:commit_seqno:sha256(record_value_bytes)` (hex), sorted ascending by
  key, joined with `;`, hashed with SHA-256 (hex).

All fields must be exactly right together. A record that looks like the Sanjeevani but rests on
a write the mountain never truly committed, on an undecoded or uncalibrated spectrum, or on the
wrong patch of ground, will be refused.
