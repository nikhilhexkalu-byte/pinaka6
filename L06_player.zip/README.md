# L06 — Dashanana: The Eleventh Truth  (FINAL BOSS)

*Ten heads, ten crowns, ten authorities — and Ravana trusted every one of them. The Sovereign
Vault of Lanka does not open for a key, a password, or a signature. It opens only when the ten
authorities **agree** that one and the same decree has been lawfully **authorized**, durably
**committed**, faithfully **recovered** after every fault, and **cryptographically proven** —
all four, all pointing at the selfsame act. No single head can open it. The vault is the eleventh
truth the other ten were built to defend.*

*You are not a head of state. You hold no sovereign seal, no treasury key, no recovery firmware
signing authority. You are an ordinary enrolled principal with an allowance of one. And yet —
Lanka fell not to a greater army, but to the smallest disagreement between things that were each,
on their own, telling the truth.*

## Target

A single **Sovereign-Vault Gateway** is exposed; it speaks JSON over HTTP. Behind it are ten
logical authorities — Identity, Policy, Time, Memory, Cryptographic-Proof, State-Mirror,
Recovery, Audit-Witness, and the Sovereign-Vault itself. Query `GET /` on your instance for the
authority map. Connection details are provided by the platform.

You are also given one internal artifact the Recovery authority runs: `recovery_firmware`, the
compiled binary that reconstructs committed state after a fault. It is yours to reverse.

## Goal

Make the Sovereign-Vault **release** — obtain the sealed secret of Lanka (the flag). The vault
releases only when its four-way check all passes at once:

- the decree is **authorized** under its logical identity,
- it is **committed** under its storage identity,
- it is **recovery-consistent** in the firmware's reconstructed state, and
- it is **cryptographically proven** by a transcript bound to that same identity.

A legitimate sovereign holds all four and can open the vault. You hold none of them, and may act
only as an enrolled principal. No single authority is broken; each will tell you the truth about
what it sees. The vault's belief that the four truths describe **the same transaction** is the
only thing standing between you and the secret.

The flag is released by the Sovereign-Vault, server-side, only when its own join accepts the
state you present. **There is no flag in any file.**
