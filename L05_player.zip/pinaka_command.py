#!/usr/bin/env python3
r"""PINAKA L05 "The Last Astra -- An Unprovable Command" -- PUBLIC command-sanction primitive.

This is the exact client-side module the Astra command desk ships. It contains NO secrets: only
the public gadget arithmetic and the TWO verification layers ("twin seals") the desk runs. Load
the scheme parameters and the order registry from the JSON files beside this module
(params.json, instance.json).

THE PRIMITIVE  (gadget syndrome opening -- SIS/Ajtai flavoured)
--------------------------------------------------------------
The public sanction matrix is  A = I_m (x) g  (block-diagonal), gadget row g = (B^0,...,B^{k-1}).
A command is a bounded word-vector v in [0,B)^(m*k). Its syndrome is  t = A.v, i.e. register i's
syndrome is  t_i = sum_l v[i*k+l] * B^l. An order (a named public syndrome t) is LAWFUL iff it
has a bounded opening over the integers Z: exists v in [0,B)^n with A.v == t over Z.

THE TWO SEALS the desk runs (it fires only if BOTH accept)
---------------------------------------------------------
    Dharma Seal (algebraic / fast field) : accept (v,t) iff bounds hold AND A.v == t (mod p)
    Rigor  Seal (bit-exact / "formal")   : accept (v,t) iff bounds hold AND A.v == t (mod p2)

NOTE for researchers: each seal compares the syndrome ONLY modulo its own prime, and neither
checks that the target t is itself within the achievable integer range [0, B**k). Study what the
two seals do and do NOT jointly pin about the syndrome.
"""
import json, os

_HERE = os.path.dirname(os.path.abspath(__file__))


def load_params(path=None):
    with open(path or os.path.join(_HERE, "params.json")) as f:
        return json.load(f)


def load_instance(path=None):
    with open(path or os.path.join(_HERE, "instance.json")) as f:
        return json.load(f)


def gadget(B, k):
    return [pow(B, l) for l in range(k)]


def matvec(v, B, k, m):
    """A.v for the block-diagonal gadget A = I_m (x) g, over the integers Z."""
    g = gadget(B, k)
    return [sum(v[i * k + l] * g[l] for l in range(k)) for i in range(m)]


def bounds_ok(v, B, k, m):
    return isinstance(v, list) and len(v) == m * k and all(isinstance(x, int) and 0 <= x < B for x in v)


def opening(x, B, k):
    """G^{-1}: the (unique) bounded opening of an in-range register value x in [0, B**k)."""
    out = []
    for _ in range(k):
        out.append(x % B); x //= B
    if x != 0:
        raise ValueError("value out of gadget range (no bounded opening)")
    return out


def dharma_seal(params, v, t):
    """Algebraic / fast field verifier -- accepts iff bounds hold and A.v == t (mod p)."""
    g = params["gadget"]; B, k, m = g["B"], g["k"], g["m"]
    p = params["seals"]["dharma_seal"]["modulus_p"]
    if not bounds_ok(v, B, k, m):
        return False
    s = matvec(v, B, k, m)
    return all((s[i] - int(t[i])) % p == 0 for i in range(m))


def rigor_seal(params, v, t):
    """Bit-exact / 'formal' verifier -- accepts iff bounds hold and A.v == t (mod p2)."""
    g = params["gadget"]; B, k, m = g["B"], g["k"], g["m"]
    p2 = params["seals"]["rigor_seal"]["modulus_p2"]
    if not bounds_ok(v, B, k, m):
        return False
    s = matvec(v, B, k, m)
    return all((s[i] - int(t[i])) % p2 == 0 for i in range(m))


def both_seals(params, v, t):
    """The deployed guard: fire iff BOTH seals accept."""
    return dharma_seal(params, v, t) and rigor_seal(params, v, t)


if __name__ == "__main__":
    # self-check: the shipped lawful order's witness opening is accepted by both seals.
    params = load_params(); inst = load_instance()
    order = inst["orders"]["hold-position"]
    v = order["witness_opening"]; t = order["syndrome"]
    print("hold-position: dharma =", dharma_seal(params, v, t),
          " rigor =", rigor_seal(params, v, t),
          " both =", both_seals(params, v, t))
