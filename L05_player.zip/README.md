# L05 — The Last Astra: An Unprovable Command

*On the field before Lanka stands the last and most terrible weapon of Rama's host — the
Brahmashirsha, the Astra that could unmake creation. It answers only to a **sanctioned
command**: an order that carries a proof it is lawful. So that no single mistaken hand could ever
loose it, the sages set **two seals** upon the command desk — **Vibhishana's Dharma Seal**, a
swift judge of the order's balance, and **Lakshmana's Rigor Seal**, an exact one — and bound the
Astra to fire only when **both** seals are satisfied. Two seals, they reasoned, could never both
be deceived at once. But the two seals do not weigh the order on the same scale, and no one ever
proved that their two judgements must agree. There is a command no lawful order could ever
justify — yet a command that **both** seals will accept.*

## Target

A single HTTP/JSON service — the **Astra command desk**. Connection details for your instance
are provided by the platform.

Public endpoints:

| Method / path | What it returns |
|---|---|
| `GET /astra/params` | The gadget **sanction matrix** parameters (`B, k, m`) and the two seals' rules, including each seal's prime (`p`, `p2`). |
| `GET /astra/registry` | The **order registry**: the lawful orders (with their syndromes and honest openings) and the **forbidden order** `loose-last-astra` (with its syndrome). |
| `POST /astra/command` | Body `{"order": <name>, "command": [<n integers>]}`. The desk runs **both** seals on your command against that order's syndrome. |

The public command primitive (`pinaka_command.py`) and the instance files (`params.json`,
`instance.json`) ship alongside this brief. Read them: the gadget sanction scheme and **both**
verification layers are fully specified there.

## The scheme

The sanction matrix is the block-diagonal gadget `A = I_m ⊗ (B^0, B^1, …, B^{k-1})`. A
**command** is a bounded word-vector `v` with `0 ≤ v_j < B`. Its **syndrome** is `t = A·v`; for
register `i`, `t_i = Σ_l v[i·k + l]·B^l`. An order (a named public syndrome `t`) is **lawful**
iff it has such a bounded opening **over the integers**.

The desk fires an order iff **both** seals accept your command against that order's syndrome:

```
Dharma Seal :  0 ≤ v_j < B  for all j   AND   A·v ≡ t   (mod p)
Rigor  Seal :  0 ≤ v_j < B  for all j   AND   A·v ≡ t   (mod p2)
```

## Goal

Make the desk **loose the Last Astra** — fire the forbidden order `loose-last-astra` — by
submitting a command that **both** seals accept against its published syndrome. You hold only
what is public: the parameters, the registry, and the two seals' rules. There is no signing key,
no secret opening, and the forbidden order has no honest bounded opening at all.

Submit to `POST /astra/command` with `"order": "loose-last-astra"` and your command as a list of
`n = m·k` integers. The desk validates server-side with both seals and returns the proclamation
(the flag) only when both accept. **There is no flag in any file.**
