# L01 — Angada: The Unshaken Oath

*Lanka. In Ravana's city the exiled prince Vibhishana keeps a chancery of his own — a quiet
embassy where the terms of war and peace are drafted, sealed, and carried between courts. Every
document passes down an **oath-chain**: the sovereign swears authority to a herald, the herald to
an envoy, and the envoy carries only what he is sworn to carry. You are **Angada**, an envoy of
that chancery. You are trusted with routine correspondence — courtesies, safe-conducts, the small
business of embassies. You are **not** sworn to carry the sealed war-council terms.*

*The chancery is careful. A sealed matter may be authored only by the sovereign. Before anything
is carried to a court it must be **cleared** by the chancery scribe, who reviews each draft in his
own time and seals a certificate when he is satisfied. The sealed terms, the scribe will tell you,
are never cleared for an envoy's hand.*

*And yet an oath, once sworn, is unshaken. The question is what a faithful envoy may carry if
every step of his day is, on its own, entirely within his right.*

## Target

A single HTTP service (JSON) is exposed: the **Lanka diplomatic chancery**. It offers documents
and revisions, an **oath-chain delegation** authority, an **asynchronous approval engine** (a
background scribe who reviews drafts and issues signed clearance certificates), an audit history,
and a **court dispatch** that releases a document's current content to the envoy's court.

Enrol as the envoy with `POST /chancery/enroll`; send `X-Session` and
`Authorization: Bearer <token>` on every request. Explore the chancery from there. Connection
details for your instance are provided by the platform.

## Goal

Cause the chancery to **dispatch the sealed war-council terms into your hand** — and read the
sealed reply the chancery swore no envoy would ever carry.

You hold no sovereign's seal and may not author sealed matter. You may act only as the envoy you
are: draft routine revisions you are cleared to draft, submit drafts for the scribe's review,
reposition a document within its own history, and dispatch what you are sworn to dispatch. Each of
those acts is legitimate. Find the ordering in which, together, they are not.

The sealed reply is released by the chancery, server-side, only when a dispatch genuinely carries
it to your court. There is no flag in any file you are given.
