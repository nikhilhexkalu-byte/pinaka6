# L02 — Kumbhakarna: The Sleepless Curse

*Kumbhakarna, brother of Ravana, lies under the sleepless curse: six months he sleeps, and no
ordinary clamour can rouse him. The wrights of Lanka built an awakening-engine for the war —
conches, war-drums, and a mechanism of wheels — that must be sounded in exactly the right way to
drive the sleep from him. The engine survives as a firmware image and a stripped emulator. The
engine is not one machine but two that answer each other, and a drum keeps time within it. Learn
the engine. Then sound the six-fold summons, and the eyes will open.*

## What you are given
- `firmware.rom` — the awakening-engine's firmware for the PRAHARA processor.
- `prahara_emu` — the engine emulator (a stripped native binary). It runs the firmware on a
  six-fold summons you provide and reports whether the eyes opened.

```
./prahara_emu firmware.rom <b0> <b1> <b2> <b3> <b4> <b5>
```
Each `b` is one summons word (a decimal number). It prints:
```
awake=<0|1>
sleep_depth=<the engine's remaining sleep-depth>
garjana=<hex of the roar/trace stream>
tag=<64 hex characters — the resonance attestation>
```

## Goal
Find the **six-fold summons** that drives the engine to its **awake** state — the mechanism's
sleep-depth all the way to zero so the eyes open — then sound it to the Lanka gate. The PRAHARA
is an original machine, and it is a *pair* of them: a main processor and a second little engine it
drives in its own language, with a drum-timer that stirs the machine as it runs. Nothing about the
real instruction set, the second language, or the drum's schedule is written down for you —
recover it all from the firmware and the emulator.

## Submission
The gate is served over HTTP by the platform for your instance. Submit:
```
POST /lanka/awaken
{ "summons": [b0, b1, b2, b3, b4, b5], "attestation": "<the 64-hex tag>" }
```
The eyes open — and the flag is released — only when your summons **awakens** the engine **and**
the resonance attestation you submit matches the one the true engine emits. A correct summons
without the correct attestation is not enough: you must have actually sounded it on the real
machine. There is no flag anywhere in the firmware or the emulator; it lives only behind the gate.
